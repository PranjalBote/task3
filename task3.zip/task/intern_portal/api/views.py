
from django.shortcuts import render
from django.http import JsonResponse , HttpResponse
from django.http import HttpResponse



# Static dummy data
DUMMY_TOTAL_DONATIONS = 10000
DUMMY_USER_DATA = {
    "name": "Pranjal Bote",
    "referral_code": "pranjal2025",
    "donations_raised": 3400
}

def get_intern_data(request):
    return JsonResponse(DUMMY_USER_DATA)


def home(request):


    return render(request, 'api/index.html', {'total_donations': DUMMY_TOTAL_DONATIONS})


def submit_form(request):
    if request.method == "POST":
        name = request.POST.get("name","").strip()
        referral_code = request.POST.get("code","").strip() # should match your input name

        # Basic server-side checks
        if not name or not referral_code:
            return HttpResponse("Error: All fields are required.")

        if not name.replace(" ", "").isalpha():
            return HttpResponse("Error: Name must contain only letters.")

        if len(referral_code) < 5:
            return HttpResponse("Error: Referral code too short.")

        donations = DUMMY_USER_DATA["donations_raised"]


        return render(request, 'api/success.html', {
            'name': name,
            'referral_code':referral_code ,
            'donations_raised': donations
        })
    return HttpResponse("Invalid request.")
def submit_view(request):
    if request.method == "POST":
        name = request.POST.get('name')
        code = request.POST.get('code')
        # Save to DB here if needed
        return render(request, 'dashboard.html', {'name': name, 'code': code})
