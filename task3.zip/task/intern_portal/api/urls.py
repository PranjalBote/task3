from django.urls import path
from .views import get_intern_data
from . import views

urlpatterns = [
    path('intern/', get_intern_data),
    path('', views.home, name='home'),
    path('submit/', views.submit_form, name='submit_form'),
]
