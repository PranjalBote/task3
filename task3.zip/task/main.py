


def print_hi(name):

    print(f'Hi, {name}')



if __name__ == '__main__':
    print_hi('PyCharm')

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
